#include <iostream>
#include "game_of_life.h"

int main(){

	GameOfLife game = GameOfLife();
	game.motherboard();
}